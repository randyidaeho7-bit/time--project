import DataService from './DataService';
import AnalysisService from './AnalysisService';

export {
    DataService,
    AnalysisService
};